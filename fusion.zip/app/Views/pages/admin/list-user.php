<?= view('pages/admin/template/header') ?>


<div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-users-cog"></i> Data User</h1>
	<a href="<?= base_url('admin/tambah-user') ?>" class="btn btn-success"> <i class="fa fa-plus"></i> Tambah Data </a>
</div>

<?php if (session()->getFlashdata('success')): ?>
	<div class="alert alert-success alert-dismissible fade show" role="alert">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
		<?= session()->getFlashdata('success') ?>
	</div>
<?php endif; ?>

<?php if (session()->getFlashdata('error')): ?>
	<div class="alert alert-danger alert-dismissible fade show" role="alert">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
		<?= session()->getFlashdata('error') ?>
	</div>
<?php endif; ?>

<div class="card shadow mb-4">
	<!-- /.card-header -->
	<div class="card-header py-3">
		<h6 class="m-0 font-weight-bold text-success"><i class="fa fa-table"></i> Daftar Data User</h6>
	</div>

	<div class="card-body">
		<div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
				<thead class="bg-success text-white">
					<tr align="center">
						<th width="5%">No</th>
						<th>Nama User</th>
						<th>Email</th>
						<th>Role</th>
						<th width="15%">Aksi</th>
					</tr>
				</thead>
				<tbody>
					<?php $no = 1;
					foreach ($users as $user): ?>
						<tr align="center">
							<td><?= $no++ ?></td>
							<td><?= esc($user['nama']) ?></td>
							<td><?= esc($user['email']) ?></td>
							<td><?= esc($user['role']) ?></td>
							<td>
								<div class="btn-group" role="group">
									<a data-toggle="tooltip" data-placement="bottom" title="Edit Data"
										href="<?= base_url('admin/edit-user/' . $user['id_user']) ?>"
										class="btn btn-warning btn-sm">
										<i class="fa fa-edit"></i>
									</a>

									<a href="#" data-toggle="modal" data-target="#modalHapus" data-hapus-url="<?= base_url('admin/hapus-user/' . $user['id_user']) ?>"
										class="btn btn-danger btn-sm" data-placement="bottom" title="Hapus Data">
										<i class="fa fa-trash"></i>
									</a>
								</div>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>

<?= view('pages/admin/template/footer') ?>